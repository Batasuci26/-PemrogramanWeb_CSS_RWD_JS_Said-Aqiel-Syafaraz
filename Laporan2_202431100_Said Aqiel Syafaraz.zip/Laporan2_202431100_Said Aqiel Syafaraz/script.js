const user = {
  name: "Said Aqiel Syafaraz",
  nim: "202431100",
  gender: "L"
};

function applyTheme() {
  const root = document.documentElement;
  const n = parseInt(user.nim.slice(-1) || "0", 10);
  const isOdd = (n % 2) === 1;

  let themeColor = "#8B4513";

  if (user.gender.toUpperCase() === "L") {
    themeColor = isOdd ? "#8B4513" : "#2E8B57";
  } else {
    themeColor = isOdd ? "#6a0dad" : "#ff69b4";
  }

  let bg = "#FFF7EF";
  if (themeColor === "#2E8B57") bg = "#08a439ff";
  if (themeColor === "#6a0dad") bg = "#F7EEFF";
  if (themeColor === "#ff69b4") bg = "#FFF0F7";

  root.style.setProperty('--theme-main', themeColor);
  root.style.setProperty('--bg', bg);
  root.style.setProperty('--text-color', '#000000');
}

function setIdentitas() {
  const el = document.getElementById('identitas');
  const el2 = document.getElementById('identitas2');
  const txt = `${user.name} — NIM: ${user.nim}`;
  if (el) el.textContent = txt;
  if (el2) el2.textContent = txt;
}

function setupToggles() {
  const titles = document.querySelectorAll('.toggle-title');
  titles.forEach(title => {
    title.addEventListener('click', () => {
      const p = title.nextElementSibling;
      if (!p) return;
      if (!p.classList.contains('hidden')) {
        const ok = confirm('Apakah Anda ingin menyembunyikan penjelasan ini?');
        if (ok) p.classList.add('hidden');
      } else {
        const ok = confirm('Apakah Anda ingin menampilkan penjelasan ini?');
        if (ok) p.classList.remove('hidden');
      }
    });
  });
}

function setupModeToggle() {
  const btn = document.getElementById('modeBtn');
  if (!btn) return;
  const saved = localStorage.getItem('siteMode');
  let isRapi = saved !== 'berantakan';
  document.body.classList.toggle('messy', !isRapi);
  btn.textContent = isRapi ? 'Mode: Rapi' : 'Mode: Berantakan';

  btn.addEventListener('click', () => {
    isRapi = !isRapi;
    document.body.classList.toggle('messy', !isRapi);
    btn.textContent = isRapi ? 'Mode: Rapi' : 'Mode: Berantakan';
    try { localStorage.setItem('siteMode', isRapi ? 'rapi' : 'berantakan'); } catch (e) { /* ignore */ }
  });
}

function setupShowImages() {
  const btn = document.getElementById('showImagesBtn');
  if (!btn) return;
  btn.addEventListener('click', () => {
    window.location.href = 'images.html';
  });
}

function setupBackButton() {
  const back = document.getElementById('backBtn');
  if (!back) return;
  back.addEventListener('click', () => {
    window.location.href = 'index.html';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  applyTheme();
  setIdentitas();
  setupToggles();
  setupModeToggle();
  setupShowImages();
  setupBackButton();
});
